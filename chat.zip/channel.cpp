#include "channel.h"
#include<QFile>
#include<QDebug>
#include <QJsonDocument>
#include <QJsonParseError>
#include<QJsonObject>
#include<QJsonArray>
#include<QJsonValue>
channel::channel(user in_Owner , QString in_ChannelName)
{
    Owner = in_Owner ;
    ChannelName = in_ChannelName ;
}
void channel::set_ChannelName(QString in_ChannelName)
{
    ChannelName = in_ChannelName ;
}
QString channel::get_ChannelName()
{
    return ChannelName ;
}
QVector<user> channel::get_Members()
{
    return Members  ;
}
QString channel::ExtractFileName( int ChannelID )
{
    QString FileName = "Channe" + QString::number(ChannelID) + ".json" ;
    return FileName ;
}
void channel::Make_NewChannelFile( QString FileName  )
{
    QFile ChannelFile(FileName) ;
    if( !ChannelFile.open(QFile::WriteOnly ) )
    {
        qDebug() << "Error in making newFile " ;//
        return ;
    }
    QJsonParseError JsonParseError ;
    QJsonDocument JsonDoc = QJsonDocument::fromJson( ChannelFile.readAll() , &JsonParseError) ;
    QJsonObject OwnerObj ;
    OwnerObj["ID"] = Owner.get_ID() ;
    OwnerObj["UserName"] = Owner.get_UserName() ;
    OwnerObj["PhoneNumber"] = Owner.get_PhoneNumber() ;
    QJsonObject RootObject = JsonDoc.object() ;
    RootObject["ID"] = ID ;
    RootObject["Owner"] = OwnerObj ;
    RootObject["Messages"] = "" ;
    RootObject["Members"] = "" ;
    JsonDoc.setObject( RootObject ) ;
    ChannelFile.write( JsonDoc.toJson() ) ;
    ChannelFile.close() ;
}
void channel::add_Member(user in_Member , QString FileName)
{
    QFile ChFile( FileName ) ;
    if( !ChFile.open(QIODevice::ReadOnly) )
    {
       qDebug() << "File open error";//temp// error dialog should be open here
       return ;
    }
    QJsonObject NewMember ;
    NewMember.insert("ID", in_Member.get_ID() ) ;
    NewMember.insert("UserName", in_Member.get_UserName()) ;
    NewMember.insert("PhoneNumber", in_Member.get_PhoneNumber()) ;
    QJsonParseError JsonParseError ;
    QJsonDocument JsonDoc = QJsonDocument::fromJson(ChFile.readAll(), &JsonParseError) ;
    ChFile.close() ;
    QJsonObject RootObject = JsonDoc.object() ;
    QJsonArray MembersArray = RootObject.value("Members").toArray() ;
    MembersArray.append( NewMember ) ;
    RootObject.insert("Members", MembersArray );
    JsonDoc.setObject(RootObject) ;
    ChFile.open(QFile::WriteOnly | QFile::Text | QFile::Truncate);
    ChFile.write( JsonDoc.toJson() ) ;
    ChFile.close() ;
}
