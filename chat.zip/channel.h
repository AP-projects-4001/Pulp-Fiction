#ifndef CHANNEL_H
#define CHANNEL_H

#include "chat.h"

class channel : public chat
{
private:
    QVector<user> Members  ;
    QString ChannelName ;
public:
    channel(user in_Owner , QString in_ChannelName);
    void set_ChannelName(QString in_ChannelName) ;
    QString get_ChannelName() ;
    void add_Member(user in_Member , QString FileName) ;
    QVector<user> get_Members() ;
    QString ExtractFileName( int ChannelID ) ;
    void Make_NewChannelFile( QString FileName  ) ;
};

#endif // CHANNEL_H
