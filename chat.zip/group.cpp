#include "group.h"
#include<QFile>
#include<QDebug>
#include <QJsonDocument>
#include <QJsonParseError>
#include<QJsonObject>
#include<QJsonArray>
#include<QJsonValue>
Group::Group(user in_Owner , QString in_GroupName)
{
    Owner = in_Owner ;
    GroupName = in_GroupName ;
}
QString Group::get_GroupName()
{
    return GroupName ;
}
void Group::set_GroupName(QString in_GroupName)
{
    GroupName = in_GroupName ;
}
void Group::add_Member(user in_Member , QString FileName)
{
    QFile GFile( FileName ) ;
    if( !GFile.open(QIODevice::ReadOnly) )
    {
       qDebug() << "File open error";//temp// error dialog should be open here
       return ;
    }
    QJsonObject NewMember ;
    NewMember.insert("ID", in_Member.get_ID() ) ;
    NewMember.insert("UserName", in_Member.get_UserName()) ;
    NewMember.insert("PhoneNumber", in_Member.get_PhoneNumber()) ;
    QJsonParseError JsonParseError ;
    QJsonDocument JsonDoc = QJsonDocument::fromJson(GFile.readAll(), &JsonParseError) ;
    GFile.close() ;
    QJsonObject RootObject = JsonDoc.object() ;
    QJsonArray MembersArray = RootObject.value("Members").toArray() ;
    MembersArray.append( NewMember ) ;
    RootObject.insert("Members", MembersArray );
    JsonDoc.setObject(RootObject) ;
    GFile.open(QFile::WriteOnly | QFile::Text | QFile::Truncate);
    GFile.write( JsonDoc.toJson() ) ;
    GFile.close() ;
}
QVector<user> Group::get_Member()
{
    return Members ;
}
QString Group::ExtractFileName( int GroupID )
{
    QString FileName = "Group" + QString::number(GroupID) + ".json" ;
    return FileName ;
}
void Group::Make_NewGroupFile( QString FileName  )
{
    QFile GroupFile(FileName) ;
    if( !GroupFile.open(QFile::WriteOnly ) )
    {
        qDebug() << "Error in making newFile " ;//
        return ;
    }
    QJsonParseError JsonParseError ;
    QJsonDocument JsonDoc = QJsonDocument::fromJson( GroupFile.readAll() , &JsonParseError) ;
    QJsonObject OwnerObj ;
    OwnerObj["ID"] = Owner.get_ID() ;
    OwnerObj["UserName"] = Owner.get_UserName() ;
    OwnerObj["PhoneNumber"] = Owner.get_PhoneNumber() ;
    QJsonObject RootObject = JsonDoc.object() ;
    RootObject["ID"] = ID ;
    RootObject["Owner"] = OwnerObj ;
    RootObject["Messages"] = "" ;
    RootObject["Members"] = "" ;
    JsonDoc.setObject( RootObject ) ;
    GroupFile.write( JsonDoc.toJson() ) ;
    GroupFile.close() ;
}
