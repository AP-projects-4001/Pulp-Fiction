#ifndef MAINDATABASE_H
#define MAINDATABASE_H
#include "user.h"

class maindatabase
{
public:
    maindatabase();
    static int Creat_ID() ;
    static void Add_user(user in_user) ;
    static bool Check_username(QString in_username) ;//for sign in
    static bool Check_PhoneNumber(QString in_PhoneNumber) ;//for sign in
    static bool Check_EmailAddress(QString in_EmailAddress) ;//for sign in
    static bool Find_user( user &in_user ) ;//for login
    static void Push_UserPVChatID() ;
    static void Push_UserGroupID() ;
    static void Push_UserChannelID() ;
    static void Push_UserFriendID() ;
    static void Delete_UserFriendID() ;
};

#endif // MAINDATABASE_H
