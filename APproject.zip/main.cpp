#include "pulp.h"
#include "maindatabase.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Pulp w;  
    w.show();
    return a.exec();
}
/*test main 1:
 *     user tmpuser ;
    if ( maindatabase::Check_username("hasan")== true )
    {
        tmpuser.set_UserName("hasan") ;
        tmpuser.set_ID( maindatabase::Creat_ID() ) ;
        tmpuser.set_Password( "12345678" ) ;
        tmpuser.set_PhoneNumber("111111111") ;
        maindatabase::Add_user( tmpuser ) ;
    }
    else
    {
        qDebug() << "bad username" ;
    }*/
/*test main 2:
 *         user tmpuser ;
        tmpuser.set_UserName("hasan") ;
        tmpuser.set_ID( maindatabase::Creat_ID() ) ;
        tmpuser.set_Password( "12345678" ) ;
        tmpuser.set_PhoneNumber("111111111") ;
        if(maindatabase::Find_user( tmpuser ) )
        {
            qDebug() << "found!" ;
        }*/
