#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QListWidgetItem>
#include "baseclass.h"
#include "channelclass.h"
#include "groupclass.h"
#include "pvclass.h"
#include <QTextEdit>
#include <QVBoxLayout>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
enum Mode { ChatMode, ChannnelMode, PvMode };
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    void vectroToList(QVector<QString> write);
    ~MainWindow();

public slots:
    void clicked_list_item(QListWidgetItem* item);
    void send_clicked();
    void infp_clicked();

signals:
   void itemClicked(QListWidgetItem*);

private:
    Ui::MainWindow *ui;

    QVector<QListWidgetItem*> chat;
    QVector<baseClass*> vec;

    int index;
    QString name;
    int ID;

    channelClass* ob;
    groupClass* ob1;
    pvClass* ob2;

    Mode currentMode ;


    void Display(bool isAd);
    //user* howAmI;
    //QVBoxLayout* mainLayout;



};
#endif // MAINWINDOW_H
