#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "baseclass.h"
#include "channelclass.h"
#include "groupclass.h"
#include "pvclass.h"
#include <QGraphicsBlurEffect>
#include <QScrollArea>
#include <QTextBoundaryFinder>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->messageLine->hide();
    ui->infoButton->hide();
    ui->sendButton->hide();
    //ui->name->hide();
    ui->listWidget->hide();

    QListWidgetItem* item = new QListWidgetItem;
    QListWidgetItem* item1 = new QListWidgetItem;
    QListWidgetItem* item2 = new QListWidgetItem;
    item->setIcon(QIcon("C:/Users/Arefe/Desktop/ri_film.png"));
    item1->setIcon(QIcon("C:/Users/Arefe/Desktop/ADM_vector_icons_Students copy 2.png"));
    item2->setIcon(QIcon("C:/Users/Arefe/Desktop/500_F_209954204_mHCvAQBIXP7C2zRl5Fbs6MEWOEkaX3cA.jpg"));
    ui->sidebar->addItem(item);
    ui->sidebar->addItem(item1);
    ui->sidebar->addItem(item2);
    ui->sidebar->setMinimumWidth(ui->sidebar->sizeHintForColumn(0));

   // ui->centralwidget(ui->label_2);

    QVector<QString> vecme = {"arash","negar"};
    QVector<QString> vecMes = {"hello","bye" , "group"};
    QVector<int> vint= {1,2,3};
    QVector<int> vin= {1,2,3};
    int i = 4;
    QString s ="iut";
    QString n = "arefe";
    QVector<QString> vecAd = {"fhf","fjjf"};
    ob1 = new groupClass(i,n,s,6,vin,vecme,vint,vecAd , vecMes );
    vec.push_back(ob1);

    QVector<QString> vecme1 = {"arash","negar"};
    QVector<QString> vecMes1 = {"hello","bye" , "channel"};
    QVector<int> vint1= {1,2,3};
    QVector<int> vin1= {1,2,3};
    int i1 = 4;
    QString s1 ="iut";
    QVector<QString> vecAd1 = {"fhf","fjjf"};
    ob = new channelClass(i1,s1,6,vin1,vecme1,vint1,vecAd1 , vecMes1 );
    vec.push_back(ob);

    QVector<QString> vecMes2 = {"hello","bye" , "pv"};
    int i2 = 4;
    QString s2 ="iut";
    ob2 = new pvClass(i2,6, s2 , vecMes2);
    vec.push_back(ob2);

    ui->chatList->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);


    for(int a = 0 ; a < 3 ; a++)
    {
        QListWidgetItem* item = new QListWidgetItem;
        item->setText(QString::number(a));
        item->setForeground(Qt::white);
        chat.push_back(item);
        ui->chatList->addItem(item);
    }

    connect(ui->chatList, SIGNAL(itemClicked(QListWidgetItem*)),
                this, SLOT(clicked_list_item(QListWidgetItem*)));
    connect(ui->sendButton, &QPushButton::clicked,
         this, &MainWindow::send_clicked);
    connect(ui->infoButton, &QPushButton::clicked,
         this, &MainWindow::infp_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::clicked_list_item(QListWidgetItem* item)
{
    //multi
    //thread t1(returnmes)
    //thread t2(send_clicked)
    for(int i = 0; i < ui->chatList->count(); ++i)
    {
        if(ui->chatList->item(i) == item)
        {
            baseClass* ptr = vec[i];
            index = i;
            //ui->messageEdit->clear();
            vectroToList(ptr->getMessages());
            groupClass* ptr1 = dynamic_cast<groupClass*>(ptr);
            if(ptr1 != nullptr)
            {
                currentMode = ChatMode;
                Display(true);
                return;
            }
            channelClass* ptr2 = dynamic_cast<channelClass*>(ptr);
            if(ptr2 != nullptr)
            {
                currentMode = ChannnelMode;
                Display(ptr2->getAdmin());
                return;
            }
            pvClass* ptr3 = dynamic_cast<pvClass*>(ptr);
            if(ptr3 != nullptr)
            {
                currentMode = PvMode;
                Display(true);
                return;
            }

        }
    }
}

void MainWindow::Display(bool isAd)
{
    ui->messageLine->hide();
    ui->sendButton->hide();
    ui->infoButton->hide();
    //ui->textEdit->show();
    ui->messageLine->clear();
    //ui->textEdit->setReadOnly(true);
    //ui->textEdit->setStyleSheet("background-color : rgba(255,0,0,10%); color : white;");
    //ui->name->show();
    if(isAd)
    {
        ui->messageLine->show();
        ui->sendButton->show();
        ui->infoButton->show();
    }
}
void MainWindow::send_clicked()
{
    QString mes = ui->messageLine->text();
    if(!(mes.isEmpty()))
    {
    //ui->textEdit->append(mes);
    //ui->textEdit->clear();
    //ui->textEdit->setFocus(Qt::OtherFocusReason);
    }

}
void MainWindow::infp_clicked()
{
    if(currentMode != PvMode)
    {
         //channel_and_chat_dialog* obDialog= new channel_and_chat_dialog(vec[index]);
        // obDialog->setStyleSheet("QWidget{\
                                 background-color: black\
                                 }");
        // obDialog->show();
    }
}
void MainWindow::vectroToList(QVector<QString> write)
{

    /*QLabel *label =  new QLabel();
    label->setText("This is how i add a label");
    label->setMinimumWidth(100);
    ui->verticalLayout->addWidget(label);*/
    ui->listWidget->show();
    ui->listWidget->setStyleSheet("background-color : rgba(255,0,0,0%); color : white;");
    ui->listWidget->setFlow(QListView::LeftToRight);
    ui->listWidget->setGridSize(QSize(300, 90));
    ui->listWidget->setResizeMode(QListView::Adjust);
    ui->listWidget->setViewMode(QListView::ListMode);
    ui->listWidget->setWrapping(true);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->setSizeConstraint(QLayout::SetMinimumSize);
    this->setLayout(layout);
    ui->listWidget->clear();
    for (int i = 0 ; i < 5 ; i ++) {
        auto    item = new QListWidgetItem("", ui->listWidget);
        auto    text = new QLabel("content is kddddddddddddddddddddddddd dkkkkkkkkkkkkkkkkkkkkkkkk kdddddddddd  kfkkkkkkkkkkkkkkkk kdkdkdkdk kdkkdkdkdk ");
        text->setStyleSheet("QLabel { background-color : black; color : white; }");
        text->setMinimumSize(200, 80);
        text->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
        text->setWordWrap(true);
        layout->addWidget(text);


        ui->listWidget->setItemWidget(item, text);
    }

    /*QVector<QString>::iterator itt;
    for (itt = write.begin(); itt != write.end(); ++itt)
    {
        read->append(*itt);
    }*/


}
